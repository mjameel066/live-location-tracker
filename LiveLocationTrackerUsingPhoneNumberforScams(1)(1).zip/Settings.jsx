import { useState, useEffect } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { deviceAPI, emergencyAPI, userAPI, phoneAPI } from '../lib/api'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  User, 
  Smartphone, 
  Users, 
  Shield, 
  Plus, 
  Trash2, 
  Edit,
  Phone,
  CheckCircle,
  AlertTriangle
} from 'lucide-react'
import Navbar from './Navbar'

export default function Settings() {
  const { user } = useAuth()
  const [devices, setDevices] = useState([])
  const [contacts, setContacts] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  // Profile form state
  const [profileData, setProfileData] = useState({
    first_name: '',
    last_name: '',
    phone_number: ''
  })

  // Device form state
  const [deviceForm, setDeviceForm] = useState({
    device_name: '',
    device_identifier: '',
    device_type: 'android'
  })

  // Contact form state
  const [contactForm, setContactForm] = useState({
    contact_name: '',
    phone_number: '',
    relationship: '',
    is_primary: false
  })

  // Password form state
  const [passwordForm, setPasswordForm] = useState({
    current_password: '',
    new_password: '',
    confirm_password: ''
  })

  useEffect(() => {
    loadSettingsData()
  }, [user])

  const loadSettingsData = async () => {
    try {
      setLoading(true)
      const [devicesResponse, contactsResponse] = await Promise.all([
        deviceAPI.getDevices(),
        emergencyAPI.getContacts()
      ])

      if (devicesResponse.data.success) {
        setDevices(devicesResponse.data.data)
      }

      if (contactsResponse.data.success) {
        setContacts(contactsResponse.data.data)
      }

      // Set profile data from user
      if (user) {
        setProfileData({
          first_name: user.first_name || '',
          last_name: user.last_name || '',
          phone_number: user.phone_number || ''
        })
      }
    } catch (err) {
      setError('Failed to load settings data')
      console.error('Settings error:', err)
    } finally {
      setLoading(false)
    }
  }

  const updateProfile = async (e) => {
    e.preventDefault()
    try {
      const response = await userAPI.updateProfile(profileData)
      if (response.data.success) {
        setSuccess('Profile updated successfully')
        setTimeout(() => setSuccess(''), 3000)
      }
    } catch (err) {
      setError('Failed to update profile')
    }
  }

  const changePassword = async (e) => {
    e.preventDefault()
    
    if (passwordForm.new_password !== passwordForm.confirm_password) {
      setError('New passwords do not match')
      return
    }

    try {
      const response = await userAPI.changePassword({
        current_password: passwordForm.current_password,
        new_password: passwordForm.new_password
      })
      
      if (response.data.success) {
        setSuccess('Password changed successfully')
        setPasswordForm({ current_password: '', new_password: '', confirm_password: '' })
        setTimeout(() => setSuccess(''), 3000)
      }
    } catch (err) {
      setError('Failed to change password')
    }
  }

  const addDevice = async (e) => {
    e.preventDefault()
    try {
      const response = await deviceAPI.registerDevice(deviceForm)
      if (response.data.success) {
        setDevices([...devices, response.data.data])
        setDeviceForm({ device_name: '', device_identifier: '', device_type: 'android' })
        setSuccess('Device added successfully')
        setTimeout(() => setSuccess(''), 3000)
      }
    } catch (err) {
      setError('Failed to add device')
    }
  }

  const deleteDevice = async (deviceId) => {
    try {
      const response = await deviceAPI.deleteDevice(deviceId)
      if (response.data.success) {
        setDevices(devices.filter(d => d.id !== deviceId))
        setSuccess('Device removed successfully')
        setTimeout(() => setSuccess(''), 3000)
      }
    } catch (err) {
      setError('Failed to remove device')
    }
  }

  const addContact = async (e) => {
    e.preventDefault()
    try {
      const response = await emergencyAPI.addContact(contactForm)
      if (response.data.success) {
        setContacts([...contacts, response.data.data])
        setContactForm({ contact_name: '', phone_number: '', relationship: '', is_primary: false })
        setSuccess('Emergency contact added successfully')
        setTimeout(() => setSuccess(''), 3000)
      }
    } catch (err) {
      setError('Failed to add emergency contact')
    }
  }

  const deleteContact = async (contactId) => {
    try {
      const response = await emergencyAPI.deleteContact(contactId)
      if (response.data.success) {
        setContacts(contacts.filter(c => c.id !== contactId))
        setSuccess('Emergency contact removed successfully')
        setTimeout(() => setSuccess(''), 3000)
      }
    } catch (err) {
      setError('Failed to remove emergency contact')
    }
  }

  const verifyPhone = async () => {
    try {
      const response = await phoneAPI.validateUserPhone(profileData.phone_number)
      if (response.data.success) {
        setSuccess('Phone number verified successfully')
        setTimeout(() => setSuccess(''), 3000)
      }
    } catch (err) {
      setError('Failed to verify phone number')
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
          <p className="text-gray-600 mt-2">
            Manage your account, devices, and emergency contacts
          </p>
        </div>

        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="mb-6 border-green-200 bg-green-50">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800">{success}</AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="profile" className="flex items-center space-x-2">
              <User className="h-4 w-4" />
              <span>Profile</span>
            </TabsTrigger>
            <TabsTrigger value="devices" className="flex items-center space-x-2">
              <Smartphone className="h-4 w-4" />
              <span>Devices</span>
            </TabsTrigger>
            <TabsTrigger value="contacts" className="flex items-center space-x-2">
              <Users className="h-4 w-4" />
              <span>Contacts</span>
            </TabsTrigger>
            <TabsTrigger value="security" className="flex items-center space-x-2">
              <Shield className="h-4 w-4" />
              <span>Security</span>
            </TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <CardTitle>Profile Information</CardTitle>
                <CardDescription>
                  Update your personal information and contact details
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={updateProfile} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="first_name">First Name</Label>
                      <Input
                        id="first_name"
                        value={profileData.first_name}
                        onChange={(e) => setProfileData({...profileData, first_name: e.target.value})}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="last_name">Last Name</Label>
                      <Input
                        id="last_name"
                        value={profileData.last_name}
                        onChange={(e) => setProfileData({...profileData, last_name: e.target.value})}
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="phone_number">Phone Number</Label>
                    <div className="flex space-x-2">
                      <Input
                        id="phone_number"
                        type="tel"
                        value={profileData.phone_number}
                        onChange={(e) => setProfileData({...profileData, phone_number: e.target.value})}
                        placeholder="+1234567890"
                      />
                      <Button type="button" variant="outline" onClick={verifyPhone}>
                        <Phone className="h-4 w-4 mr-2" />
                        Verify
                      </Button>
                    </div>
                  </div>
                  
                  <Button type="submit">Update Profile</Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Devices Tab */}
          <TabsContent value="devices">
            <div className="space-y-6">
              {/* Add Device */}
              <Card>
                <CardHeader>
                  <CardTitle>Add New Device</CardTitle>
                  <CardDescription>
                    Register a new device for location tracking
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={addDevice} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="device_name">Device Name</Label>
                        <Input
                          id="device_name"
                          value={deviceForm.device_name}
                          onChange={(e) => setDeviceForm({...deviceForm, device_name: e.target.value})}
                          placeholder="John's iPhone"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="device_type">Device Type</Label>
                        <select
                          id="device_type"
                          value={deviceForm.device_type}
                          onChange={(e) => setDeviceForm({...deviceForm, device_type: e.target.value})}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md"
                        >
                          <option value="android">Android</option>
                          <option value="ios">iOS</option>
                          <option value="web">Web Browser</option>
                        </select>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="device_identifier">Device Identifier</Label>
                      <Input
                        id="device_identifier"
                        value={deviceForm.device_identifier}
                        onChange={(e) => setDeviceForm({...deviceForm, device_identifier: e.target.value})}
                        placeholder="unique_device_id_123"
                        required
                      />
                    </div>
                    
                    <Button type="submit">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Device
                    </Button>
                  </form>
                </CardContent>
              </Card>

              {/* Device List */}
              <Card>
                <CardHeader>
                  <CardTitle>Your Devices</CardTitle>
                  <CardDescription>
                    Manage your registered devices
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {devices.length === 0 ? (
                    <div className="text-center py-8">
                      <Smartphone className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">No devices registered yet</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {devices.map((device) => (
                        <div key={device.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center space-x-3">
                            <Smartphone className="h-5 w-5 text-gray-600" />
                            <div>
                              <h3 className="font-medium">{device.device_name}</h3>
                              <p className="text-sm text-gray-600">
                                {device.device_type} • Status: {device.consent_status}
                              </p>
                            </div>
                          </div>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => deleteDevice(device.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Emergency Contacts Tab */}
          <TabsContent value="contacts">
            <div className="space-y-6">
              {/* Add Contact */}
              <Card>
                <CardHeader>
                  <CardTitle>Add Emergency Contact</CardTitle>
                  <CardDescription>
                    Add people who should be notified in case of emergency
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={addContact} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="contact_name">Contact Name</Label>
                        <Input
                          id="contact_name"
                          value={contactForm.contact_name}
                          onChange={(e) => setContactForm({...contactForm, contact_name: e.target.value})}
                          placeholder="John Doe"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="contact_phone">Phone Number</Label>
                        <Input
                          id="contact_phone"
                          type="tel"
                          value={contactForm.phone_number}
                          onChange={(e) => setContactForm({...contactForm, phone_number: e.target.value})}
                          placeholder="+1234567890"
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="relationship">Relationship</Label>
                      <Input
                        id="relationship"
                        value={contactForm.relationship}
                        onChange={(e) => setContactForm({...contactForm, relationship: e.target.value})}
                        placeholder="Father, Mother, Spouse, etc."
                      />
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="is_primary"
                        checked={contactForm.is_primary}
                        onChange={(e) => setContactForm({...contactForm, is_primary: e.target.checked})}
                        className="rounded"
                      />
                      <Label htmlFor="is_primary">Primary emergency contact</Label>
                    </div>
                    
                    <Button type="submit">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Contact
                    </Button>
                  </form>
                </CardContent>
              </Card>

              {/* Contact List */}
              <Card>
                <CardHeader>
                  <CardTitle>Emergency Contacts</CardTitle>
                  <CardDescription>
                    People who will be notified during emergencies
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {contacts.length === 0 ? (
                    <div className="text-center py-8">
                      <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">No emergency contacts added yet</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {contacts.map((contact) => (
                        <div key={contact.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center space-x-3">
                            <Users className="h-5 w-5 text-gray-600" />
                            <div>
                              <h3 className="font-medium">
                                {contact.contact_name}
                                {contact.is_primary && (
                                  <span className="ml-2 text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                                    Primary
                                  </span>
                                )}
                              </h3>
                              <p className="text-sm text-gray-600">
                                {contact.phone_number}
                                {contact.relationship && ` • ${contact.relationship}`}
                              </p>
                            </div>
                          </div>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => deleteContact(contact.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Security Tab */}
          <TabsContent value="security">
            <Card>
              <CardHeader>
                <CardTitle>Change Password</CardTitle>
                <CardDescription>
                  Update your account password for better security
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={changePassword} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="current_password">Current Password</Label>
                    <Input
                      id="current_password"
                      type="password"
                      value={passwordForm.current_password}
                      onChange={(e) => setPasswordForm({...passwordForm, current_password: e.target.value})}
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="new_password">New Password</Label>
                    <Input
                      id="new_password"
                      type="password"
                      value={passwordForm.new_password}
                      onChange={(e) => setPasswordForm({...passwordForm, new_password: e.target.value})}
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="confirm_password">Confirm New Password</Label>
                    <Input
                      id="confirm_password"
                      type="password"
                      value={passwordForm.confirm_password}
                      onChange={(e) => setPasswordForm({...passwordForm, confirm_password: e.target.value})}
                      required
                    />
                  </div>
                  
                  <Button type="submit">
                    <Shield className="h-4 w-4 mr-2" />
                    Change Password
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

