from flask import Blueprint, request, jsonify
from datetime import datetime
from src.models.user import db, Geofence, GeofenceEvent, Device
from src.routes.auth import token_required

geofences_bp = Blueprint('geofences', __name__)

@geofences_bp.route('/', methods=['GET'])
@token_required
def get_geofences(current_user):
    try:
        geofences = Geofence.query.filter_by(user_id=current_user.id).all()
        
        return jsonify({
            'success': True,
            'data': [geofence.to_dict() for geofence in geofences],
            'message': 'Geofences retrieved successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Failed to retrieve geofences: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@geofences_bp.route('/', methods=['POST'])
@token_required
def create_geofence(current_user):
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['device_id', 'name', 'center_lat', 'center_lng', 'radius']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'message': f'{field} is required',
                    'timestamp': datetime.utcnow().isoformat()
                }), 400
        
        # Verify device belongs to user
        device = Device.query.filter_by(id=data['device_id'], user_id=current_user.id).first()
        if not device:
            return jsonify({
                'success': False,
                'message': 'Device not found or not owned by user',
                'timestamp': datetime.utcnow().isoformat()
            }), 404
        
        # Validate radius (reasonable limits)
        radius = float(data['radius'])
        if radius < 10 or radius > 50000:  # 10 meters to 50 km
            return jsonify({
                'success': False,
                'message': 'Radius must be between 10 and 50000 meters',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        geofence = Geofence(
            user_id=current_user.id,
            device_id=data['device_id'],
            name=data['name'],
            description=data.get('description'),
            center_lat=data['center_lat'],
            center_lng=data['center_lng'],
            radius=radius,
            alert_on_enter=data.get('alert_on_enter', True),
            alert_on_exit=data.get('alert_on_exit', True)
        )
        
        db.session.add(geofence)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': geofence.to_dict(),
            'message': 'Geofence created successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Failed to create geofence: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@geofences_bp.route('/<int:geofence_id>', methods=['GET'])
@token_required
def get_geofence(current_user, geofence_id):
    try:
        geofence = Geofence.query.filter_by(id=geofence_id, user_id=current_user.id).first()
        if not geofence:
            return jsonify({
                'success': False,
                'message': 'Geofence not found',
                'timestamp': datetime.utcnow().isoformat()
            }), 404
        
        return jsonify({
            'success': True,
            'data': geofence.to_dict(),
            'message': 'Geofence retrieved successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Failed to retrieve geofence: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@geofences_bp.route('/<int:geofence_id>', methods=['PUT'])
@token_required
def update_geofence(current_user, geofence_id):
    try:
        data = request.get_json()
        
        geofence = Geofence.query.filter_by(id=geofence_id, user_id=current_user.id).first()
        if not geofence:
            return jsonify({
                'success': False,
                'message': 'Geofence not found',
                'timestamp': datetime.utcnow().isoformat()
            }), 404
        
        # Update allowed fields
        if 'name' in data:
            geofence.name = data['name']
        if 'description' in data:
            geofence.description = data['description']
        if 'center_lat' in data:
            geofence.center_lat = data['center_lat']
        if 'center_lng' in data:
            geofence.center_lng = data['center_lng']
        if 'radius' in data:
            radius = float(data['radius'])
            if radius < 10 or radius > 50000:
                return jsonify({
                    'success': False,
                    'message': 'Radius must be between 10 and 50000 meters',
                    'timestamp': datetime.utcnow().isoformat()
                }), 400
            geofence.radius = radius
        if 'alert_on_enter' in data:
            geofence.alert_on_enter = data['alert_on_enter']
        if 'alert_on_exit' in data:
            geofence.alert_on_exit = data['alert_on_exit']
        if 'is_active' in data:
            geofence.is_active = data['is_active']
        
        geofence.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': geofence.to_dict(),
            'message': 'Geofence updated successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Failed to update geofence: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@geofences_bp.route('/<int:geofence_id>', methods=['DELETE'])
@token_required
def delete_geofence(current_user, geofence_id):
    try:
        geofence = Geofence.query.filter_by(id=geofence_id, user_id=current_user.id).first()
        if not geofence:
            return jsonify({
                'success': False,
                'message': 'Geofence not found',
                'timestamp': datetime.utcnow().isoformat()
            }), 404
        
        db.session.delete(geofence)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Geofence deleted successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Failed to delete geofence: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@geofences_bp.route('/<int:geofence_id>/events', methods=['GET'])
@token_required
def get_geofence_events(current_user, geofence_id):
    try:
        # Verify geofence belongs to user
        geofence = Geofence.query.filter_by(id=geofence_id, user_id=current_user.id).first()
        if not geofence:
            return jsonify({
                'success': False,
                'message': 'Geofence not found',
                'timestamp': datetime.utcnow().isoformat()
            }), 404
        
        # Get query parameters
        limit = int(request.args.get('limit', 50))
        if limit > 100:
            limit = 100
        
        events = GeofenceEvent.query.filter_by(geofence_id=geofence_id)\
                                   .order_by(GeofenceEvent.timestamp.desc())\
                                   .limit(limit).all()
        
        return jsonify({
            'success': True,
            'data': [event.to_dict() for event in events],
            'message': 'Geofence events retrieved successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Failed to retrieve geofence events: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@geofences_bp.route('/device/<int:device_id>', methods=['GET'])
@token_required
def get_device_geofences(current_user, device_id):
    try:
        # Verify device belongs to user
        device = Device.query.filter_by(id=device_id, user_id=current_user.id).first()
        if not device:
            return jsonify({
                'success': False,
                'message': 'Device not found',
                'timestamp': datetime.utcnow().isoformat()
            }), 404
        
        geofences = Geofence.query.filter_by(device_id=device_id, user_id=current_user.id).all()
        
        return jsonify({
            'success': True,
            'data': [geofence.to_dict() for geofence in geofences],
            'message': 'Device geofences retrieved successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Failed to retrieve device geofences: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

