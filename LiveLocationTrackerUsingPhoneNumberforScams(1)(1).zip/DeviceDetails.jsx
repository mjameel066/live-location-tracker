import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { deviceAPI, locationAPI } from '../lib/api'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  ArrowLeft, 
  Smartphone, 
  MapPin, 
  Battery, 
  Clock, 
  Activity,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Pause
} from 'lucide-react'
import Navbar from './Navbar'
import MapView from './MapView'

export default function DeviceDetails() {
  const { deviceId } = useParams()
  const [device, setDevice] = useState(null)
  const [locationHistory, setLocationHistory] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [updating, setUpdating] = useState(false)

  useEffect(() => {
    loadDeviceData()
  }, [deviceId])

  const loadDeviceData = async () => {
    try {
      setLoading(true)
      const [deviceResponse, historyResponse] = await Promise.all([
        deviceAPI.getDevices(),
        locationAPI.getLocationHistory(deviceId, { limit: 50 })
      ])

      if (deviceResponse.data.success) {
        const deviceData = deviceResponse.data.data.find(d => d.id === parseInt(deviceId))
        if (deviceData) {
          setDevice(deviceData)
        } else {
          setError('Device not found')
        }
      }

      if (historyResponse.data.success) {
        setLocationHistory(historyResponse.data.data.locations || [])
      }
    } catch (err) {
      setError('Failed to load device data')
      console.error('Device details error:', err)
    } finally {
      setLoading(false)
    }
  }

  const updateConsentStatus = async (status) => {
    try {
      setUpdating(true)
      const response = await deviceAPI.updateConsent(deviceId, status)
      
      if (response.data.success) {
        setDevice(response.data.data)
      } else {
        setError('Failed to update consent status')
      }
    } catch (err) {
      setError('Failed to update consent status')
      console.error('Consent update error:', err)
    } finally {
      setUpdating(false)
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800'
      case 'pending': return 'bg-yellow-100 text-yellow-800'
      case 'paused': return 'bg-gray-100 text-gray-800'
      case 'revoked': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case 'active': return <CheckCircle className="h-4 w-4" />
      case 'pending': return <Clock className="h-4 w-4" />
      case 'paused': return <Pause className="h-4 w-4" />
      case 'revoked': return <XCircle className="h-4 w-4" />
      default: return <AlertTriangle className="h-4 w-4" />
    }
  }

  const formatDateTime = (timestamp) => {
    if (!timestamp) return 'Never'
    return new Date(timestamp).toLocaleString()
  }

  const formatCoordinate = (coord) => {
    if (!coord) return 'N/A'
    return parseFloat(coord).toFixed(6)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
        </div>
      </div>
    )
  }

  if (error || !device) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>{error || 'Device not found'}</AlertDescription>
          </Alert>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center space-x-4 mb-4">
            <Button variant="outline" size="sm" asChild>
              <Link to="/dashboard">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Link>
            </Button>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-blue-100 rounded-lg">
                <Smartphone className="h-8 w-8 text-blue-600" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">{device.device_name}</h1>
                <p className="text-gray-600">Device ID: {device.id}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Badge className={getStatusColor(device.consent_status)}>
                {getStatusIcon(device.consent_status)}
                <span className="ml-1">{device.consent_status}</span>
              </Badge>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Device Info & Controls */}
          <div className="lg:col-span-1 space-y-6">
            {/* Device Status */}
            <Card>
              <CardHeader>
                <CardTitle>Device Status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Consent Status</span>
                  <Badge className={getStatusColor(device.consent_status)}>
                    {device.consent_status}
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Online Status</span>
                  <Badge className={device.is_online ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                    {device.is_online ? 'Online' : 'Offline'}
                  </Badge>
                </div>
                
                {device.battery_level && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Battery Level</span>
                    <div className="flex items-center space-x-2">
                      <Battery className="h-4 w-4 text-gray-600" />
                      <span className="text-sm font-medium">{device.battery_level}%</span>
                    </div>
                  </div>
                )}
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Device Type</span>
                  <span className="text-sm font-medium capitalize">{device.device_type}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Created</span>
                  <span className="text-sm font-medium">{formatDateTime(device.created_at)}</span>
                </div>
              </CardContent>
            </Card>

            {/* Location Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MapPin className="h-5 w-5" />
                  <span>Current Location</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {device.last_location?.latitude && device.last_location?.longitude ? (
                  <>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-gray-600">Latitude</span>
                        <p className="font-mono">{formatCoordinate(device.last_location.latitude)}</p>
                      </div>
                      <div>
                        <span className="text-gray-600">Longitude</span>
                        <p className="font-mono">{formatCoordinate(device.last_location.longitude)}</p>
                      </div>
                    </div>
                    
                    {device.last_location.accuracy && (
                      <div className="text-sm">
                        <span className="text-gray-600">Accuracy</span>
                        <p>{device.last_location.accuracy}m</p>
                      </div>
                    )}
                    
                    <div className="text-sm">
                      <span className="text-gray-600">Last Updated</span>
                      <p>{formatDateTime(device.last_location.timestamp)}</p>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-4">
                    <MapPin className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-600">No location data available</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Consent Controls */}
            <Card>
              <CardHeader>
                <CardTitle>Tracking Controls</CardTitle>
                <CardDescription>
                  Manage location tracking consent for this device
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {device.consent_status !== 'active' && (
                  <Button 
                    className="w-full" 
                    onClick={() => updateConsentStatus('active')}
                    disabled={updating}
                  >
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Activate Tracking
                  </Button>
                )}
                
                {device.consent_status === 'active' && (
                  <Button 
                    variant="outline" 
                    className="w-full" 
                    onClick={() => updateConsentStatus('paused')}
                    disabled={updating}
                  >
                    <Pause className="h-4 w-4 mr-2" />
                    Pause Tracking
                  </Button>
                )}
                
                <Button 
                  variant="destructive" 
                  className="w-full" 
                  onClick={() => updateConsentStatus('revoked')}
                  disabled={updating}
                >
                  <XCircle className="h-4 w-4 mr-2" />
                  Revoke Consent
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Map & History */}
          <div className="lg:col-span-2 space-y-6">
            {/* Map */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MapPin className="h-5 w-5" />
                  <span>Device Location</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="h-96">
                  <MapView devices={[device]} />
                </div>
              </CardContent>
            </Card>

            {/* Location History */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="h-5 w-5" />
                  <span>Location History</span>
                </CardTitle>
                <CardDescription>
                  Recent location updates from this device
                </CardDescription>
              </CardHeader>
              <CardContent>
                {locationHistory.length > 0 ? (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {locationHistory.map((location, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <MapPin className="h-4 w-4 text-gray-600" />
                          <div>
                            <p className="text-sm font-medium">
                              {formatCoordinate(location.latitude)}, {formatCoordinate(location.longitude)}
                            </p>
                            <p className="text-xs text-gray-600">
                              {location.accuracy && `±${location.accuracy}m`}
                              {location.location_source && ` • ${location.location_source}`}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-gray-600">
                            {formatDateTime(location.timestamp)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Activity className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-600">No location history available</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

