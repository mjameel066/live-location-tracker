from flask import Blueprint, request, jsonify
from datetime import datetime
from src.models.user import db, Device
from src.routes.auth import token_required

devices_bp = Blueprint('devices', __name__)

@devices_bp.route('/', methods=['GET'])
@token_required
def get_devices(current_user):
    try:
        devices = Device.query.filter_by(user_id=current_user.id).all()
        
        return jsonify({
            'success': True,
            'data': [device.to_dict() for device in devices],
            'message': 'Devices retrieved successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Failed to retrieve devices: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@devices_bp.route('/', methods=['POST'])
@token_required
def register_device(current_user):
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['device_name', 'device_identifier', 'device_type']
        for field in required_fields:
            if not data.get(field):
                return jsonify({
                    'success': False,
                    'message': f'{field} is required',
                    'timestamp': datetime.utcnow().isoformat()
                }), 400
        
        # Check if device already exists
        existing_device = Device.query.filter_by(device_identifier=data['device_identifier']).first()
        if existing_device:
            return jsonify({
                'success': False,
                'message': 'Device with this identifier already exists',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        # Create new device
        device = Device(
            user_id=current_user.id,
            device_name=data['device_name'],
            device_identifier=data['device_identifier'],
            device_type=data['device_type']
        )
        
        db.session.add(device)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': device.to_dict(),
            'message': 'Device registered successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Device registration failed: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@devices_bp.route('/<int:device_id>/consent', methods=['PUT'])
@token_required
def update_consent(current_user, device_id):
    try:
        data = request.get_json()
        
        if not data.get('consent_status'):
            return jsonify({
                'success': False,
                'message': 'consent_status is required',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        valid_statuses = ['pending', 'active', 'paused', 'revoked']
        if data['consent_status'] not in valid_statuses:
            return jsonify({
                'success': False,
                'message': f'Invalid consent_status. Must be one of: {", ".join(valid_statuses)}',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        device = Device.query.filter_by(id=device_id, user_id=current_user.id).first()
        if not device:
            return jsonify({
                'success': False,
                'message': 'Device not found',
                'timestamp': datetime.utcnow().isoformat()
            }), 404
        
        device.consent_status = data['consent_status']
        device.consent_timestamp = datetime.utcnow()
        device.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': device.to_dict(),
            'message': 'Consent status updated successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Failed to update consent: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@devices_bp.route('/<int:device_id>', methods=['DELETE'])
@token_required
def delete_device(current_user, device_id):
    try:
        device = Device.query.filter_by(id=device_id, user_id=current_user.id).first()
        if not device:
            return jsonify({
                'success': False,
                'message': 'Device not found',
                'timestamp': datetime.utcnow().isoformat()
            }), 404
        
        db.session.delete(device)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Device removed successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Failed to delete device: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@devices_bp.route('/<int:device_id>', methods=['GET'])
@token_required
def get_device(current_user, device_id):
    try:
        device = Device.query.filter_by(id=device_id, user_id=current_user.id).first()
        if not device:
            return jsonify({
                'success': False,
                'message': 'Device not found',
                'timestamp': datetime.utcnow().isoformat()
            }), 404
        
        return jsonify({
            'success': True,
            'data': device.to_dict(),
            'message': 'Device retrieved successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Failed to retrieve device: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@devices_bp.route('/<int:device_id>', methods=['PUT'])
@token_required
def update_device(current_user, device_id):
    try:
        data = request.get_json()
        
        device = Device.query.filter_by(id=device_id, user_id=current_user.id).first()
        if not device:
            return jsonify({
                'success': False,
                'message': 'Device not found',
                'timestamp': datetime.utcnow().isoformat()
            }), 404
        
        # Update allowed fields
        if 'device_name' in data:
            device.device_name = data['device_name']
        if 'device_type' in data:
            device.device_type = data['device_type']
        
        device.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': device.to_dict(),
            'message': 'Device updated successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Failed to update device: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

