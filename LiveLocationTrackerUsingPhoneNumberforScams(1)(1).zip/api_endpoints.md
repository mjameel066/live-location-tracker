# API Endpoints Documentation for Live Location Tracker Application

## Overview
This document defines the RESTful API endpoints for the Live Location Tracker Application. The API follows REST conventions and uses JSON for data exchange. All endpoints require proper authentication unless otherwise specified.

## Base URL
```
https://api.locationtracker.com/v1
```

## Authentication
All protected endpoints require a Bearer token in the Authorization header:
```
Authorization: Bearer <jwt_token>
```

## Response Format
All API responses follow this standard format:
```json
{
  "success": true|false,
  "data": {...},
  "message": "Success message or error description",
  "timestamp": "2025-01-07T10:30:00Z"
}
```

## Error Codes
- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `422` - Validation Error
- `500` - Internal Server Error

---

## 1. Authentication Endpoints

### POST /auth/register
Register a new user account.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "securePassword123",
  "first_name": "John",
  "last_name": "Doe",
  "phone_number": "+1234567890"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "user_id": 123,
    "email": "user@example.com",
    "token": "jwt_token_here"
  },
  "message": "User registered successfully"
}
```

### POST /auth/login
Authenticate user and return JWT token.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "securePassword123"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "user_id": 123,
    "email": "user@example.com",
    "token": "jwt_token_here",
    "expires_at": "2025-01-08T10:30:00Z"
  },
  "message": "Login successful"
}
```

### POST /auth/logout
Invalidate the current JWT token.

**Headers:** `Authorization: Bearer <token>`

**Response:**
```json
{
  "success": true,
  "message": "Logged out successfully"
}
```

### POST /auth/refresh
Refresh JWT token.

**Headers:** `Authorization: Bearer <token>`

**Response:**
```json
{
  "success": true,
  "data": {
    "token": "new_jwt_token_here",
    "expires_at": "2025-01-08T10:30:00Z"
  },
  "message": "Token refreshed successfully"
}
```

---

## 2. User Management Endpoints

### GET /users/profile
Get current user's profile information.

**Headers:** `Authorization: Bearer <token>`

**Response:**
```json
{
  "success": true,
  "data": {
    "id": 123,
    "email": "user@example.com",
    "first_name": "John",
    "last_name": "Doe",
    "phone_number": "+1234567890",
    "phone_verified": true,
    "created_at": "2025-01-01T00:00:00Z"
  }
}
```

### PUT /users/profile
Update user profile information.

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "first_name": "John",
  "last_name": "Smith",
  "phone_number": "+1234567890"
}
```

### POST /users/verify-phone
Verify user's phone number.

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "phone_number": "+1234567890"
}
```

---

## 3. Device Management Endpoints

### GET /devices
Get all devices associated with the current user.

**Headers:** `Authorization: Bearer <token>`

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 456,
      "device_name": "John's iPhone",
      "device_type": "ios",
      "consent_status": "active",
      "last_location": {
        "latitude": 40.7128,
        "longitude": -74.0060,
        "timestamp": "2025-01-07T10:25:00Z",
        "accuracy": 5.0
      },
      "battery_level": 85,
      "is_online": true
    }
  ]
}
```

### POST /devices
Register a new device for tracking.

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "device_name": "John's iPhone",
  "device_identifier": "unique_device_token_123",
  "device_type": "ios"
}
```

### PUT /devices/{device_id}/consent
Update device consent status.

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "consent_status": "active|paused|revoked"
}
```

### DELETE /devices/{device_id}
Remove a device from tracking.

**Headers:** `Authorization: Bearer <token>`

---

## 4. Location Tracking Endpoints

### POST /locations
Submit location data from a tracked device.

**Headers:** `Authorization: Bearer <device_token>`

**Request Body:**
```json
{
  "latitude": 40.7128,
  "longitude": -74.0060,
  "accuracy": 5.0,
  "altitude": 10.5,
  "speed": 0.0,
  "heading": 180.0,
  "location_source": "gps",
  "battery_level": 85,
  "timestamp": "2025-01-07T10:30:00Z"
}
```

### GET /locations/{device_id}/current
Get current location of a specific device.

**Headers:** `Authorization: Bearer <token>`

**Response:**
```json
{
  "success": true,
  "data": {
    "device_id": 456,
    "latitude": 40.7128,
    "longitude": -74.0060,
    "accuracy": 5.0,
    "timestamp": "2025-01-07T10:30:00Z",
    "battery_level": 85,
    "is_online": true
  }
}
```

### GET /locations/{device_id}/history
Get location history for a specific device.

**Headers:** `Authorization: Bearer <token>`

**Query Parameters:**
- `start_date` (optional): ISO 8601 date string
- `end_date` (optional): ISO 8601 date string
- `limit` (optional): Number of records (default: 100, max: 1000)

**Response:**
```json
{
  "success": true,
  "data": {
    "device_id": 456,
    "locations": [
      {
        "latitude": 40.7128,
        "longitude": -74.0060,
        "accuracy": 5.0,
        "timestamp": "2025-01-07T10:30:00Z"
      }
    ],
    "total_count": 150
  }
}
```

---

## 5. Emergency Contacts Endpoints

### GET /emergency-contacts
Get all emergency contacts for the current user.

**Headers:** `Authorization: Bearer <token>`

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 789,
      "contact_name": "Jane Doe",
      "phone_number": "+1234567891",
      "relationship": "spouse",
      "is_primary": true
    }
  ]
}
```

### POST /emergency-contacts
Add a new emergency contact.

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "contact_name": "Jane Doe",
  "phone_number": "+1234567891",
  "relationship": "spouse",
  "is_primary": false
}
```

### PUT /emergency-contacts/{contact_id}
Update an emergency contact.

### DELETE /emergency-contacts/{contact_id}
Remove an emergency contact.

---

## 6. Geofencing Endpoints

### GET /geofences
Get all geofences for the current user.

**Headers:** `Authorization: Bearer <token>`

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 101,
      "name": "Home",
      "description": "Family home area",
      "center_lat": 40.7128,
      "center_lng": -74.0060,
      "radius": 100.0,
      "alert_on_enter": true,
      "alert_on_exit": true,
      "is_active": true
    }
  ]
}
```

### POST /geofences
Create a new geofence.

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "device_id": 456,
  "name": "School",
  "description": "Child's school area",
  "center_lat": 40.7589,
  "center_lng": -73.9851,
  "radius": 200.0,
  "alert_on_enter": false,
  "alert_on_exit": true
}
```

### PUT /geofences/{geofence_id}
Update a geofence.

### DELETE /geofences/{geofence_id}
Delete a geofence.

---

## 7. Emergency Alert Endpoints

### POST /emergency/panic
Trigger a panic alert from a device.

**Headers:** `Authorization: Bearer <device_token>`

**Request Body:**
```json
{
  "latitude": 40.7128,
  "longitude": -74.0060,
  "message": "Emergency! Need help immediately!"
}
```

### GET /emergency/alerts
Get emergency alerts for the current user.

**Headers:** `Authorization: Bearer <token>`

**Query Parameters:**
- `status` (optional): `active|resolved|all`
- `limit` (optional): Number of records

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 202,
      "device_id": 456,
      "alert_type": "panic_button",
      "latitude": 40.7128,
      "longitude": -74.0060,
      "message": "Emergency! Need help immediately!",
      "is_resolved": false,
      "created_at": "2025-01-07T10:30:00Z"
    }
  ]
}
```

### PUT /emergency/alerts/{alert_id}/resolve
Mark an emergency alert as resolved.

---

## 8. Phone Number Verification Endpoints

### POST /phone/verify
Verify a phone number using third-party API.

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "phone_number": "+1234567890"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "phone_number": "+1234567890",
    "is_valid": true,
    "line_type": "mobile",
    "carrier": "T-Mobile",
    "country": "United States",
    "region": "New York"
  }
}
```

### POST /phone/lookup
Perform reverse phone lookup (if available and legal).

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "phone_number": "+1234567890"
}
```

---

## 9. Notification Endpoints

### GET /notifications
Get notification history for the current user.

**Headers:** `Authorization: Bearer <token>`

### POST /notifications/test
Send a test notification to verify SMS/email configuration.

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "type": "sms|email",
  "recipient": "+1234567890",
  "message": "Test notification message"
}
```

---

## Rate Limiting
- Authentication endpoints: 5 requests per minute per IP
- Location updates: 60 requests per minute per device
- General API endpoints: 100 requests per minute per user

## WebSocket Endpoints (Real-time Updates)
For real-time location updates and alerts:

### WS /ws/locations/{device_id}
Real-time location updates for a specific device.

### WS /ws/alerts
Real-time emergency alerts for the user.

This API documentation provides a comprehensive foundation for the Live Location Tracker Application's backend services.

