from flask import Blueprint, request, jsonify, current_app
from datetime import datetime, timedelta
import jwt
from functools import wraps
from src.models.user import db, User

auth_bp = Blueprint('auth', __name__)

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        auth_header = request.headers.get('Authorization')
        
        if auth_header:
            try:
                token = auth_header.split(" ")[1]  # Bearer <token>
            except IndexError:
                return jsonify({
                    'success': False,
                    'message': 'Invalid token format',
                    'timestamp': datetime.utcnow().isoformat()
                }), 401
        
        if not token:
            return jsonify({
                'success': False,
                'message': 'Token is missing',
                'timestamp': datetime.utcnow().isoformat()
            }), 401
        
        try:
            data = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=['HS256'])
            current_user = User.query.filter_by(id=data['user_id']).first()
            if not current_user or not current_user.is_active:
                return jsonify({
                    'success': False,
                    'message': 'Invalid token or user not active',
                    'timestamp': datetime.utcnow().isoformat()
                }), 401
        except jwt.ExpiredSignatureError:
            return jsonify({
                'success': False,
                'message': 'Token has expired',
                'timestamp': datetime.utcnow().isoformat()
            }), 401
        except jwt.InvalidTokenError:
            return jsonify({
                'success': False,
                'message': 'Invalid token',
                'timestamp': datetime.utcnow().isoformat()
            }), 401
        
        return f(current_user, *args, **kwargs)
    return decorated

def generate_token(user_id):
    payload = {
        'user_id': user_id,
        'exp': datetime.utcnow() + timedelta(days=7)  # Token expires in 7 days
    }
    return jwt.encode(payload, current_app.config['SECRET_KEY'], algorithm='HS256')

@auth_bp.route('/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['email', 'password', 'first_name', 'last_name']
        for field in required_fields:
            if not data.get(field):
                return jsonify({
                    'success': False,
                    'message': f'{field} is required',
                    'timestamp': datetime.utcnow().isoformat()
                }), 400
        
        # Check if user already exists
        if User.query.filter_by(email=data['email']).first():
            return jsonify({
                'success': False,
                'message': 'User with this email already exists',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        # Create new user
        user = User(
            email=data['email'],
            first_name=data['first_name'],
            last_name=data['last_name'],
            phone_number=data.get('phone_number')
        )
        user.set_password(data['password'])
        
        db.session.add(user)
        db.session.commit()
        
        # Generate token
        token = generate_token(user.id)
        
        return jsonify({
            'success': True,
            'data': {
                'user_id': user.id,
                'email': user.email,
                'token': token
            },
            'message': 'User registered successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Registration failed: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        
        if not data.get('email') or not data.get('password'):
            return jsonify({
                'success': False,
                'message': 'Email and password are required',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        user = User.query.filter_by(email=data['email']).first()
        
        if not user or not user.check_password(data['password']):
            return jsonify({
                'success': False,
                'message': 'Invalid email or password',
                'timestamp': datetime.utcnow().isoformat()
            }), 401
        
        if not user.is_active:
            return jsonify({
                'success': False,
                'message': 'Account is deactivated',
                'timestamp': datetime.utcnow().isoformat()
            }), 401
        
        # Update last login
        user.last_login = datetime.utcnow()
        db.session.commit()
        
        # Generate token
        token = generate_token(user.id)
        expires_at = datetime.utcnow() + timedelta(days=7)
        
        return jsonify({
            'success': True,
            'data': {
                'user_id': user.id,
                'email': user.email,
                'token': token,
                'expires_at': expires_at.isoformat()
            },
            'message': 'Login successful',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Login failed: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@auth_bp.route('/logout', methods=['POST'])
@token_required
def logout(current_user):
    # In a production environment, you might want to blacklist the token
    # For now, we'll just return a success message
    return jsonify({
        'success': True,
        'message': 'Logged out successfully',
        'timestamp': datetime.utcnow().isoformat()
    }), 200

@auth_bp.route('/refresh', methods=['POST'])
@token_required
def refresh_token(current_user):
    try:
        # Generate new token
        token = generate_token(current_user.id)
        expires_at = datetime.utcnow() + timedelta(days=7)
        
        return jsonify({
            'success': True,
            'data': {
                'token': token,
                'expires_at': expires_at.isoformat()
            },
            'message': 'Token refreshed successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Token refresh failed: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

