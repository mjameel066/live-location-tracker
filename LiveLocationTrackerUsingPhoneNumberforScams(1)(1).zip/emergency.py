from flask import Blueprint, request, jsonify
from datetime import datetime
from src.models.user import db, Device, EmergencyAlert, EmergencyContact
from src.routes.auth import token_required
from src.routes.locations import device_token_required

emergency_bp = Blueprint('emergency', __name__)

@emergency_bp.route('/panic', methods=['POST'])
@device_token_required
def trigger_panic_alert(device):
    try:
        data = request.get_json()
        
        # Create emergency alert
        alert = EmergencyAlert(
            device_id=device.id,
            alert_type='panic_button',
            latitude=data.get('latitude'),
            longitude=data.get('longitude'),
            message=data.get('message', 'Emergency! Need help immediately!')
        )
        
        db.session.add(alert)
        db.session.commit()
        
        # Send notifications to emergency contacts
        send_emergency_notifications(device, alert)
        
        return jsonify({
            'success': True,
            'data': alert.to_dict(),
            'message': 'Emergency alert triggered successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Failed to trigger emergency alert: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@emergency_bp.route('/alerts', methods=['GET'])
@token_required
def get_emergency_alerts(current_user):
    try:
        # Get query parameters
        status = request.args.get('status', 'all')
        limit = int(request.args.get('limit', 50))
        
        # Limit the maximum number of records
        if limit > 100:
            limit = 100
        
        # Get user's devices
        user_device_ids = [device.id for device in current_user.devices]
        
        query = EmergencyAlert.query.filter(EmergencyAlert.device_id.in_(user_device_ids))
        
        # Apply status filter
        if status == 'active':
            query = query.filter_by(is_resolved=False)
        elif status == 'resolved':
            query = query.filter_by(is_resolved=True)
        
        alerts = query.order_by(EmergencyAlert.created_at.desc()).limit(limit).all()
        
        return jsonify({
            'success': True,
            'data': [alert.to_dict() for alert in alerts],
            'message': 'Emergency alerts retrieved successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Failed to retrieve emergency alerts: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@emergency_bp.route('/alerts/<int:alert_id>/resolve', methods=['PUT'])
@token_required
def resolve_emergency_alert(current_user, alert_id):
    try:
        # Get user's devices
        user_device_ids = [device.id for device in current_user.devices]
        
        alert = EmergencyAlert.query.filter(
            EmergencyAlert.id == alert_id,
            EmergencyAlert.device_id.in_(user_device_ids)
        ).first()
        
        if not alert:
            return jsonify({
                'success': False,
                'message': 'Emergency alert not found',
                'timestamp': datetime.utcnow().isoformat()
            }), 404
        
        alert.is_resolved = True
        alert.resolved_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': alert.to_dict(),
            'message': 'Emergency alert resolved successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Failed to resolve emergency alert: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@emergency_bp.route('/contacts', methods=['GET'])
@token_required
def get_emergency_contacts(current_user):
    try:
        contacts = EmergencyContact.query.filter_by(user_id=current_user.id).all()
        
        return jsonify({
            'success': True,
            'data': [contact.to_dict() for contact in contacts],
            'message': 'Emergency contacts retrieved successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Failed to retrieve emergency contacts: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@emergency_bp.route('/contacts', methods=['POST'])
@token_required
def add_emergency_contact(current_user):
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['contact_name', 'phone_number']
        for field in required_fields:
            if not data.get(field):
                return jsonify({
                    'success': False,
                    'message': f'{field} is required',
                    'timestamp': datetime.utcnow().isoformat()
                }), 400
        
        # If this is set as primary, unset other primary contacts
        if data.get('is_primary', False):
            EmergencyContact.query.filter_by(user_id=current_user.id, is_primary=True).update({'is_primary': False})
        
        contact = EmergencyContact(
            user_id=current_user.id,
            contact_name=data['contact_name'],
            phone_number=data['phone_number'],
            relationship=data.get('relationship'),
            is_primary=data.get('is_primary', False)
        )
        
        db.session.add(contact)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': contact.to_dict(),
            'message': 'Emergency contact added successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Failed to add emergency contact: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@emergency_bp.route('/contacts/<int:contact_id>', methods=['PUT'])
@token_required
def update_emergency_contact(current_user, contact_id):
    try:
        data = request.get_json()
        
        contact = EmergencyContact.query.filter_by(id=contact_id, user_id=current_user.id).first()
        if not contact:
            return jsonify({
                'success': False,
                'message': 'Emergency contact not found',
                'timestamp': datetime.utcnow().isoformat()
            }), 404
        
        # If this is set as primary, unset other primary contacts
        if data.get('is_primary', False) and not contact.is_primary:
            EmergencyContact.query.filter_by(user_id=current_user.id, is_primary=True).update({'is_primary': False})
        
        # Update fields
        if 'contact_name' in data:
            contact.contact_name = data['contact_name']
        if 'phone_number' in data:
            contact.phone_number = data['phone_number']
        if 'relationship' in data:
            contact.relationship = data['relationship']
        if 'is_primary' in data:
            contact.is_primary = data['is_primary']
        
        contact.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': contact.to_dict(),
            'message': 'Emergency contact updated successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Failed to update emergency contact: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@emergency_bp.route('/contacts/<int:contact_id>', methods=['DELETE'])
@token_required
def delete_emergency_contact(current_user, contact_id):
    try:
        contact = EmergencyContact.query.filter_by(id=contact_id, user_id=current_user.id).first()
        if not contact:
            return jsonify({
                'success': False,
                'message': 'Emergency contact not found',
                'timestamp': datetime.utcnow().isoformat()
            }), 404
        
        db.session.delete(contact)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Emergency contact deleted successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Failed to delete emergency contact: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

def send_emergency_notifications(device, alert):
    """Send emergency notifications to all emergency contacts"""
    from src.models.user import Notification
    
    try:
        # Get emergency contacts for the device owner
        contacts = EmergencyContact.query.filter_by(user_id=device.user_id).all()
        
        for contact in contacts:
            # Create notification record
            notification = Notification(
                user_id=device.user_id,
                device_id=device.id,
                notification_type='sms',
                recipient=contact.phone_number,
                subject='Emergency Alert',
                message=f"EMERGENCY: {device.device_name} has triggered a panic alert. "
                       f"Location: {alert.latitude}, {alert.longitude} at {alert.created_at.strftime('%Y-%m-%d %H:%M:%S')}. "
                       f"Message: {alert.message}"
            )
            
            db.session.add(notification)
            
            # TODO: Integrate with SMS service (Twilio, etc.)
            # For now, we'll just mark as sent
            notification.status = 'sent'
            notification.sent_at = datetime.utcnow()
        
        db.session.commit()
        
    except Exception as e:
        print(f"Error sending emergency notifications: {str(e)}")
        db.session.rollback()

