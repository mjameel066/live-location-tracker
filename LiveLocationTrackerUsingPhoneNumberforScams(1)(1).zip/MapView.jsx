import { useEffect, useRef, useState } from 'react'
import { MapPin, Smartphone, Battery, Clock } from 'lucide-react'

export default function MapView({ devices = [] }) {
  const mapRef = useRef(null)
  const [map, setMap] = useState(null)
  const [markers, setMarkers] = useState([])

  useEffect(() => {
    // Initialize map when component mounts
    if (mapRef.current && !map) {
      initializeMap()
    }
  }, [map])

  useEffect(() => {
    // Update markers when devices change
    if (map && devices) {
      updateMarkers()
    }
  }, [map, devices])

  const initializeMap = () => {
    // For demo purposes, we'll create a simple map placeholder
    // In a real implementation, you would use Google Maps, Mapbox, or OpenStreetMap
    const mapContainer = mapRef.current
    
    // Create a simple map placeholder
    mapContainer.innerHTML = `
      <div class="w-full h-full bg-gray-100 flex items-center justify-center relative overflow-hidden">
        <div class="absolute inset-0 opacity-20">
          <svg width="100%" height="100%" viewBox="0 0 400 300">
            <!-- Simple map grid -->
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#e5e7eb" stroke-width="1"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
            
            <!-- Mock roads -->
            <path d="M0,150 Q100,120 200,150 T400,150" stroke="#d1d5db" stroke-width="3" fill="none"/>
            <path d="M200,0 Q180,100 200,200 T200,300" stroke="#d1d5db" stroke-width="3" fill="none"/>
            
            <!-- Mock landmarks -->
            <circle cx="100" cy="100" r="8" fill="#10b981" opacity="0.7"/>
            <circle cx="300" cy="200" r="8" fill="#3b82f6" opacity="0.7"/>
            <rect x="150" y="120" width="20" height="20" fill="#f59e0b" opacity="0.7"/>
          </svg>
        </div>
        
        <div class="text-center z-10">
          <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
            </svg>
          </div>
          <h3 class="text-lg font-medium text-gray-900 mb-2">Interactive Map</h3>
          <p class="text-gray-600 text-sm">Device locations will appear here when available</p>
        </div>
      </div>
    `

    // Store reference for future updates
    setMap({ container: mapContainer })
  }

  const updateMarkers = () => {
    if (!map || !devices.length) return

    // Clear existing markers
    const existingMarkers = map.container.querySelectorAll('.device-marker')
    existingMarkers.forEach(marker => marker.remove())

    // Add new markers for devices with location data
    devices.forEach((device, index) => {
      if (device.last_location?.latitude && device.last_location?.longitude) {
        addDeviceMarker(device, index)
      }
    })
  }

  const addDeviceMarker = (device, index) => {
    const marker = document.createElement('div')
    marker.className = 'device-marker absolute z-20 transform -translate-x-1/2 -translate-y-1/2'
    
    // Position marker (mock positioning for demo)
    const x = 100 + (index * 80) % 200
    const y = 100 + (index * 60) % 100
    marker.style.left = `${x}px`
    marker.style.top = `${y}px`

    const statusColor = device.consent_status === 'active' ? 'bg-green-500' : 'bg-gray-500'
    const batteryLevel = device.battery_level || 0

    marker.innerHTML = `
      <div class="relative group cursor-pointer">
        <div class="w-8 h-8 ${statusColor} rounded-full flex items-center justify-center shadow-lg border-2 border-white">
          <svg class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
            <path d="M10 2L3 7v11h14V7l-7-5z"/>
          </svg>
        </div>
        
        <!-- Tooltip -->
        <div class="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-gray-900 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
          <div class="font-medium">${device.device_name}</div>
          <div class="text-gray-300">Battery: ${batteryLevel}%</div>
          <div class="text-gray-300">Status: ${device.consent_status}</div>
          <div class="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-gray-900"></div>
        </div>
      </div>
    `

    map.container.appendChild(marker)
  }

  // Fallback UI when no devices have location data
  const hasLocationData = devices.some(device => 
    device.last_location?.latitude && device.last_location?.longitude
  )

  return (
    <div className="w-full h-full relative">
      <div ref={mapRef} className="w-full h-full" />
      
      {devices.length > 0 && !hasLocationData && (
        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg text-center max-w-sm">
            <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              No Location Data
            </h3>
            <p className="text-gray-600 text-sm">
              Devices need to share their location for them to appear on the map. 
              Make sure location tracking is enabled and consent is active.
            </p>
          </div>
        </div>
      )}

      {/* Map controls */}
      <div className="absolute top-4 right-4 space-y-2">
        <button className="bg-white p-2 rounded-lg shadow-md hover:bg-gray-50 transition-colors">
          <svg className="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
        </button>
        <button className="bg-white p-2 rounded-lg shadow-md hover:bg-gray-50 transition-colors">
          <svg className="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 12H4" />
          </svg>
        </button>
      </div>

      {/* Legend */}
      {devices.length > 0 && (
        <div className="absolute bottom-4 left-4 bg-white p-3 rounded-lg shadow-md">
          <h4 className="text-sm font-medium text-gray-900 mb-2">Device Status</h4>
          <div className="space-y-1 text-xs">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <span>Active</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
              <span>Pending</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-gray-500 rounded-full"></div>
              <span>Inactive</span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

