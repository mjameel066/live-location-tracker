import { useState, useEffect } from 'react'
import { emergencyAPI } from '../lib/api'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  MapPin, 
  Smartphone,
  RefreshCw
} from 'lucide-react'
import Navbar from './Navbar'

export default function EmergencyAlerts() {
  const [alerts, setAlerts] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [resolving, setResolving] = useState(null)

  useEffect(() => {
    loadAlerts()
  }, [])

  const loadAlerts = async () => {
    try {
      setLoading(true)
      const response = await emergencyAPI.getAlerts({ limit: 100 })
      
      if (response.data.success) {
        setAlerts(response.data.data)
      } else {
        setError('Failed to load alerts')
      }
    } catch (err) {
      setError('Failed to load alerts')
      console.error('Alerts error:', err)
    } finally {
      setLoading(false)
    }
  }

  const resolveAlert = async (alertId) => {
    try {
      setResolving(alertId)
      const response = await emergencyAPI.resolveAlert(alertId)
      
      if (response.data.success) {
        // Update the alert in the list
        setAlerts(alerts.map(alert => 
          alert.id === alertId 
            ? { ...alert, is_resolved: true, resolved_at: new Date().toISOString() }
            : alert
        ))
      } else {
        setError('Failed to resolve alert')
      }
    } catch (err) {
      setError('Failed to resolve alert')
      console.error('Resolve alert error:', err)
    } finally {
      setResolving(null)
    }
  }

  const getAlertTypeColor = (type) => {
    switch (type) {
      case 'panic_button': return 'bg-red-100 text-red-800'
      case 'geofence_exit': return 'bg-orange-100 text-orange-800'
      case 'geofence_enter': return 'bg-blue-100 text-blue-800'
      case 'low_battery': return 'bg-yellow-100 text-yellow-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getAlertTypeIcon = (type) => {
    switch (type) {
      case 'panic_button': return <AlertTriangle className="h-4 w-4" />
      case 'geofence_exit': 
      case 'geofence_enter': return <MapPin className="h-4 w-4" />
      case 'low_battery': return <Smartphone className="h-4 w-4" />
      default: return <AlertTriangle className="h-4 w-4" />
    }
  }

  const formatDateTime = (timestamp) => {
    if (!timestamp) return 'Unknown'
    return new Date(timestamp).toLocaleString()
  }

  const formatCoordinate = (coord) => {
    if (!coord) return 'N/A'
    return parseFloat(coord).toFixed(6)
  }

  const activeAlerts = alerts.filter(alert => !alert.is_resolved)
  const resolvedAlerts = alerts.filter(alert => alert.is_resolved)

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Emergency Alerts</h1>
              <p className="text-gray-600 mt-2">
                Monitor and manage emergency notifications
              </p>
            </div>
            <Button onClick={loadAlerts} disabled={loading}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>

        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="h-8 w-8 text-red-600" />
                <div>
                  <p className="text-2xl font-bold text-gray-900">{activeAlerts.length}</p>
                  <p className="text-sm text-gray-600">Active Alerts</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-8 w-8 text-green-600" />
                <div>
                  <p className="text-2xl font-bold text-gray-900">{resolvedAlerts.length}</p>
                  <p className="text-sm text-gray-600">Resolved</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <Clock className="h-8 w-8 text-blue-600" />
                <div>
                  <p className="text-2xl font-bold text-gray-900">{alerts.length}</p>
                  <p className="text-sm text-gray-600">Total Alerts</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Active Alerts */}
        {activeAlerts.length > 0 && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-red-600">
                <AlertTriangle className="h-5 w-5" />
                <span>Active Emergency Alerts</span>
              </CardTitle>
              <CardDescription>
                These alerts require immediate attention
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {activeAlerts.map((alert) => (
                  <div key={alert.id} className="border border-red-200 rounded-lg p-4 bg-red-50">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <Badge className={getAlertTypeColor(alert.alert_type)}>
                            {getAlertTypeIcon(alert.alert_type)}
                            <span className="ml-1 capitalize">{alert.alert_type.replace('_', ' ')}</span>
                          </Badge>
                          <span className="text-sm text-gray-600">
                            {formatDateTime(alert.created_at)}
                          </span>
                        </div>
                        
                        <h3 className="font-medium text-gray-900 mb-2">
                          Emergency Alert from Device {alert.device_id}
                        </h3>
                        
                        {alert.message && (
                          <p className="text-gray-700 mb-3">{alert.message}</p>
                        )}
                        
                        {alert.latitude && alert.longitude && (
                          <div className="flex items-center space-x-2 text-sm text-gray-600">
                            <MapPin className="h-4 w-4" />
                            <span>
                              Location: {formatCoordinate(alert.latitude)}, {formatCoordinate(alert.longitude)}
                            </span>
                          </div>
                        )}
                      </div>
                      
                      <Button
                        onClick={() => resolveAlert(alert.id)}
                        disabled={resolving === alert.id}
                        className="ml-4"
                      >
                        {resolving === alert.id ? (
                          <>
                            <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                            Resolving...
                          </>
                        ) : (
                          <>
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Mark Resolved
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* All Alerts History */}
        <Card>
          <CardHeader>
            <CardTitle>Alert History</CardTitle>
            <CardDescription>
              Complete history of all emergency alerts
            </CardDescription>
          </CardHeader>
          <CardContent>
            {alerts.length === 0 ? (
              <div className="text-center py-12">
                <AlertTriangle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No Alerts</h3>
                <p className="text-gray-600">
                  No emergency alerts have been triggered yet. This is good news!
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {alerts.map((alert) => (
                  <div 
                    key={alert.id} 
                    className={`border rounded-lg p-4 ${
                      alert.is_resolved ? 'bg-gray-50 border-gray-200' : 'bg-red-50 border-red-200'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <Badge className={getAlertTypeColor(alert.alert_type)}>
                            {getAlertTypeIcon(alert.alert_type)}
                            <span className="ml-1 capitalize">{alert.alert_type.replace('_', ' ')}</span>
                          </Badge>
                          
                          {alert.is_resolved ? (
                            <Badge className="bg-green-100 text-green-800">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              Resolved
                            </Badge>
                          ) : (
                            <Badge className="bg-red-100 text-red-800">
                              <AlertTriangle className="h-3 w-3 mr-1" />
                              Active
                            </Badge>
                          )}
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-gray-600">Created:</span>
                            <p className="font-medium">{formatDateTime(alert.created_at)}</p>
                          </div>
                          
                          {alert.resolved_at && (
                            <div>
                              <span className="text-gray-600">Resolved:</span>
                              <p className="font-medium">{formatDateTime(alert.resolved_at)}</p>
                            </div>
                          )}
                          
                          <div>
                            <span className="text-gray-600">Device:</span>
                            <p className="font-medium">Device {alert.device_id}</p>
                          </div>
                          
                          {alert.latitude && alert.longitude && (
                            <div>
                              <span className="text-gray-600">Location:</span>
                              <p className="font-medium font-mono">
                                {formatCoordinate(alert.latitude)}, {formatCoordinate(alert.longitude)}
                              </p>
                            </div>
                          )}
                        </div>
                        
                        {alert.message && (
                          <div className="mt-3">
                            <span className="text-gray-600">Message:</span>
                            <p className="text-gray-900 mt-1">{alert.message}</p>
                          </div>
                        )}
                      </div>
                      
                      {!alert.is_resolved && (
                        <Button
                          onClick={() => resolveAlert(alert.id)}
                          disabled={resolving === alert.id}
                          size="sm"
                          className="ml-4"
                        >
                          {resolving === alert.id ? (
                            <RefreshCw className="h-4 w-4 animate-spin" />
                          ) : (
                            <CheckCircle className="h-4 w-4" />
                          )}
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

