from flask import Blueprint, request, jsonify
from datetime import datetime, timedelta
from src.models.user import db, Device, LocationHistory
from src.routes.auth import token_required
import math

locations_bp = Blueprint('locations', __name__)

def device_token_required(f):
    """Decorator for device-specific authentication"""
    from functools import wraps
    
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        auth_header = request.headers.get('Authorization')
        
        if auth_header:
            try:
                token = auth_header.split(" ")[1]  # Bearer <token>
            except IndexError:
                return jsonify({
                    'success': False,
                    'message': 'Invalid token format',
                    'timestamp': datetime.utcnow().isoformat()
                }), 401
        
        if not token:
            return jsonify({
                'success': False,
                'message': 'Device token is missing',
                'timestamp': datetime.utcnow().isoformat()
            }), 401
        
        # For simplicity, we'll use device_identifier as token
        # In production, you'd want proper JWT tokens for devices too
        device = Device.query.filter_by(device_identifier=token).first()
        if not device:
            return jsonify({
                'success': False,
                'message': 'Invalid device token',
                'timestamp': datetime.utcnow().isoformat()
            }), 401
        
        if device.consent_status not in ['active']:
            return jsonify({
                'success': False,
                'message': 'Device consent not active',
                'timestamp': datetime.utcnow().isoformat()
            }), 403
        
        return f(device, *args, **kwargs)
    return decorated

@locations_bp.route('/', methods=['POST'])
@device_token_required
def submit_location(device):
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['latitude', 'longitude', 'timestamp']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'message': f'{field} is required',
                    'timestamp': datetime.utcnow().isoformat()
                }), 400
        
        # Parse timestamp
        try:
            timestamp = datetime.fromisoformat(data['timestamp'].replace('Z', '+00:00'))
        except ValueError:
            return jsonify({
                'success': False,
                'message': 'Invalid timestamp format',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        # Create location history entry
        location = LocationHistory(
            device_id=device.id,
            latitude=data['latitude'],
            longitude=data['longitude'],
            accuracy=data.get('accuracy'),
            altitude=data.get('altitude'),
            speed=data.get('speed'),
            heading=data.get('heading'),
            location_source=data.get('location_source', 'unknown'),
            timestamp=timestamp
        )
        
        # Update device's last known location
        device.last_location_lat = data['latitude']
        device.last_location_lng = data['longitude']
        device.last_location_timestamp = timestamp
        device.last_location_accuracy = data.get('accuracy')
        device.battery_level = data.get('battery_level')
        device.is_online = True
        device.updated_at = datetime.utcnow()
        
        db.session.add(location)
        db.session.commit()
        
        # Check geofences (simplified implementation)
        check_geofences(device, data['latitude'], data['longitude'])
        
        return jsonify({
            'success': True,
            'message': 'Location updated successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Failed to update location: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@locations_bp.route('/<int:device_id>/current', methods=['GET'])
@token_required
def get_current_location(current_user, device_id):
    try:
        device = Device.query.filter_by(id=device_id, user_id=current_user.id).first()
        if not device:
            return jsonify({
                'success': False,
                'message': 'Device not found',
                'timestamp': datetime.utcnow().isoformat()
            }), 404
        
        return jsonify({
            'success': True,
            'data': {
                'device_id': device.id,
                'latitude': float(device.last_location_lat) if device.last_location_lat else None,
                'longitude': float(device.last_location_lng) if device.last_location_lng else None,
                'accuracy': float(device.last_location_accuracy) if device.last_location_accuracy else None,
                'timestamp': device.last_location_timestamp.isoformat() if device.last_location_timestamp else None,
                'battery_level': device.battery_level,
                'is_online': device.is_online
            },
            'message': 'Current location retrieved successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Failed to retrieve current location: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@locations_bp.route('/<int:device_id>/history', methods=['GET'])
@token_required
def get_location_history(current_user, device_id):
    try:
        device = Device.query.filter_by(id=device_id, user_id=current_user.id).first()
        if not device:
            return jsonify({
                'success': False,
                'message': 'Device not found',
                'timestamp': datetime.utcnow().isoformat()
            }), 404
        
        # Parse query parameters
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        limit = int(request.args.get('limit', 100))
        
        # Limit the maximum number of records
        if limit > 1000:
            limit = 1000
        
        query = LocationHistory.query.filter_by(device_id=device_id)
        
        # Apply date filters
        if start_date:
            try:
                start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
                query = query.filter(LocationHistory.timestamp >= start_dt)
            except ValueError:
                return jsonify({
                    'success': False,
                    'message': 'Invalid start_date format',
                    'timestamp': datetime.utcnow().isoformat()
                }), 400
        
        if end_date:
            try:
                end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
                query = query.filter(LocationHistory.timestamp <= end_dt)
            except ValueError:
                return jsonify({
                    'success': False,
                    'message': 'Invalid end_date format',
                    'timestamp': datetime.utcnow().isoformat()
                }), 400
        
        # Get total count
        total_count = query.count()
        
        # Apply limit and order
        locations = query.order_by(LocationHistory.timestamp.desc()).limit(limit).all()
        
        return jsonify({
            'success': True,
            'data': {
                'device_id': device_id,
                'locations': [location.to_dict() for location in locations],
                'total_count': total_count
            },
            'message': 'Location history retrieved successfully',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Failed to retrieve location history: {str(e)}',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

def calculate_distance(lat1, lon1, lat2, lon2):
    """Calculate distance between two points using Haversine formula"""
    R = 6371000  # Earth's radius in meters
    
    lat1_rad = math.radians(lat1)
    lat2_rad = math.radians(lat2)
    delta_lat = math.radians(lat2 - lat1)
    delta_lon = math.radians(lon2 - lon1)
    
    a = (math.sin(delta_lat / 2) * math.sin(delta_lat / 2) +
         math.cos(lat1_rad) * math.cos(lat2_rad) *
         math.sin(delta_lon / 2) * math.sin(delta_lon / 2))
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    
    return R * c

def check_geofences(device, latitude, longitude):
    """Check if device location triggers any geofence events"""
    from src.models.user import Geofence, GeofenceEvent
    
    try:
        # Get active geofences for this device
        geofences = Geofence.query.filter_by(device_id=device.id, is_active=True).all()
        
        for geofence in geofences:
            distance = calculate_distance(
                latitude, longitude,
                float(geofence.center_lat), float(geofence.center_lng)
            )
            
            is_inside = distance <= float(geofence.radius)
            
            # Check last event for this geofence
            last_event = GeofenceEvent.query.filter_by(
                geofence_id=geofence.id,
                device_id=device.id
            ).order_by(GeofenceEvent.timestamp.desc()).first()
            
            # Determine if we need to create an event
            should_create_event = False
            event_type = None
            
            if not last_event:
                # First time - create enter event if inside
                if is_inside and geofence.alert_on_enter:
                    should_create_event = True
                    event_type = 'enter'
            else:
                # Check for state change
                last_was_inside = last_event.event_type == 'enter'
                
                if is_inside and not last_was_inside and geofence.alert_on_enter:
                    should_create_event = True
                    event_type = 'enter'
                elif not is_inside and last_was_inside and geofence.alert_on_exit:
                    should_create_event = True
                    event_type = 'exit'
            
            if should_create_event:
                event = GeofenceEvent(
                    geofence_id=geofence.id,
                    device_id=device.id,
                    event_type=event_type,
                    latitude=latitude,
                    longitude=longitude,
                    timestamp=datetime.utcnow()
                )
                db.session.add(event)
                
                # TODO: Send notification to emergency contacts
                # This would be implemented with SMS/email service integration
        
        db.session.commit()
        
    except Exception as e:
        print(f"Error checking geofences: {str(e)}")
        db.session.rollback()

