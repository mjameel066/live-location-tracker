# Live Location Tracker - Technical Documentation

## System Architecture / سسٹم آرکیٹیکچر

### Overview
The Live Location Tracker is a full-stack web application built with Flask (backend) and React (frontend) designed for family safety and emergency protection against scam calls and kidnapping threats.

### Technology Stack

#### Backend
- **Framework:** Flask 3.1.1
- **Database:** SQLite with SQLAlchemy ORM
- **Authentication:** JWT (JSON Web Tokens)
- **CORS:** Flask-CORS for cross-origin requests
- **Phone Verification:** Custom implementation with requests library

#### Frontend
- **Framework:** React 19.1.0
- **Build Tool:** Vite 6.3.5
- **Styling:** Tailwind CSS with shadcn/ui components
- **Icons:** Lucide React
- **HTTP Client:** Axios
- **Routing:** React Router

#### Deployment
- **Backend:** Flask development server (production-ready with WSGI)
- **Frontend:** Static files served by Flask
- **Database:** SQLite (can be upgraded to PostgreSQL/MySQL)

## Project Structure

```
location_tracker_backend/
├── src/
│   ├── main.py                 # Flask application entry point
│   ├── models/
│   │   └── user.py            # Database models
│   ├── routes/
│   │   ├── auth.py            # Authentication endpoints
│   │   ├── devices.py         # Device management
│   │   ├── locations.py       # Location tracking
│   │   ├── emergency.py       # Emergency features
│   │   ├── phone.py           # Phone verification
│   │   ├── geofences.py       # Geofencing
│   │   └── user.py            # User management
│   ├── database/
│   │   └── app.db             # SQLite database
│   └── static/                # Frontend build files
├── requirements.txt           # Python dependencies
└── venv/                     # Virtual environment

location_tracker_frontend/
├── src/
│   ├── App.jsx               # Main React component
│   ├── contexts/
│   │   └── AuthContext.jsx   # Authentication context
│   ├── components/
│   │   ├── Login.jsx         # Login component
│   │   ├── Register.jsx      # Registration component
│   │   ├── Dashboard.jsx     # Main dashboard
│   │   ├── MapView.jsx       # Map visualization
│   │   ├── DeviceDetails.jsx # Device management
│   │   ├── EmergencyAlerts.jsx # Emergency system
│   │   ├── Settings.jsx      # User settings
│   │   └── Navbar.jsx        # Navigation
│   └── lib/
│       └── api.js            # API client functions
├── dist/                     # Build output
├── package.json              # Node.js dependencies
└── vite.config.js           # Vite configuration
```

## Database Schema

### Users Table
```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email VARCHAR(120) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(80),
    last_name VARCHAR(80),
    phone_number VARCHAR(20),
    is_phone_verified BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### Devices Table
```sql
CREATE TABLE devices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    device_name VARCHAR(100) NOT NULL,
    device_identifier VARCHAR(255) UNIQUE NOT NULL,
    device_type VARCHAR(20) NOT NULL,
    consent_status VARCHAR(20) DEFAULT 'pending',
    is_online BOOLEAN DEFAULT FALSE,
    battery_level INTEGER,
    last_seen DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
);
```

### Locations Table
```sql
CREATE TABLE locations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id INTEGER NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    accuracy DECIMAL(8, 2),
    altitude DECIMAL(8, 2),
    speed DECIMAL(8, 2),
    heading DECIMAL(8, 2),
    location_source VARCHAR(20) DEFAULT 'gps',
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (device_id) REFERENCES devices (id)
);
```

### Emergency Contacts Table
```sql
CREATE TABLE emergency_contacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    contact_name VARCHAR(100) NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    relationship VARCHAR(50),
    is_primary BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
);
```

### Emergency Alerts Table
```sql
CREATE TABLE emergency_alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id INTEGER NOT NULL,
    alert_type VARCHAR(50) NOT NULL,
    message TEXT,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    is_resolved BOOLEAN DEFAULT FALSE,
    resolved_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (device_id) REFERENCES devices (id)
);
```

### Geofences Table
```sql
CREATE TABLE geofences (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    name VARCHAR(100) NOT NULL,
    center_latitude DECIMAL(10, 8) NOT NULL,
    center_longitude DECIMAL(11, 8) NOT NULL,
    radius DECIMAL(8, 2) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
);
```

## API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `GET /api/auth/verify` - Verify JWT token

### User Management
- `GET /api/users/profile` - Get user profile
- `PUT /api/users/profile` - Update user profile
- `POST /api/users/change-password` - Change password

### Device Management
- `GET /api/devices` - Get user devices
- `POST /api/devices/register` - Register new device
- `PUT /api/devices/{id}/consent` - Update consent status
- `DELETE /api/devices/{id}` - Delete device

### Location Tracking
- `POST /api/locations/update` - Update device location
- `GET /api/locations/history/{device_id}` - Get location history
- `GET /api/locations/current/{device_id}` - Get current location

### Emergency Features
- `GET /api/emergency/contacts` - Get emergency contacts
- `POST /api/emergency/contacts` - Add emergency contact
- `DELETE /api/emergency/contacts/{id}` - Delete contact
- `GET /api/emergency/alerts` - Get emergency alerts
- `POST /api/emergency/panic` - Trigger panic alert
- `PUT /api/emergency/alerts/{id}/resolve` - Resolve alert

### Phone Verification
- `POST /api/phone/validate` - Validate phone number
- `POST /api/phone/lookup` - Reverse phone lookup
- `POST /api/phone/verify-user` - Verify user's phone

### Geofencing
- `GET /api/geofences` - Get user geofences
- `POST /api/geofences` - Create geofence
- `PUT /api/geofences/{id}` - Update geofence
- `DELETE /api/geofences/{id}` - Delete geofence

## Security Implementation

### Authentication
- JWT tokens for stateless authentication
- Password hashing using Werkzeug security
- Token expiration and refresh mechanism
- CORS protection for cross-origin requests

### Data Protection
- Input validation and sanitization
- SQL injection prevention through SQLAlchemy ORM
- XSS protection through proper data encoding
- HTTPS enforcement (in production)

### Privacy Controls
- Explicit consent required for location tracking
- User-controlled data retention
- Right to data deletion
- Granular permission management

## Deployment Instructions

### Local Development
1. **Backend Setup:**
   ```bash
   cd location_tracker_backend
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install -r requirements.txt
   python src/main.py
   ```

2. **Frontend Setup:**
   ```bash
   cd location_tracker_frontend
   pnpm install
   pnpm run dev
   ```

### Production Deployment
1. **Build Frontend:**
   ```bash
   cd location_tracker_frontend
   pnpm run build
   cp -r dist/* ../location_tracker_backend/src/static/
   ```

2. **Deploy Backend:**
   ```bash
   cd location_tracker_backend
   # Use production WSGI server like Gunicorn
   pip install gunicorn
   gunicorn -w 4 -b 0.0.0.0:5000 src.main:app
   ```

### Environment Variables
```bash
# Production settings
FLASK_ENV=production
SECRET_KEY=your-secret-key-here
DATABASE_URL=sqlite:///app.db  # Or PostgreSQL URL
CORS_ORIGINS=https://yourdomain.com
```

## Performance Considerations

### Database Optimization
- Index on frequently queried columns (user_id, device_id, timestamp)
- Location data archiving for old records
- Connection pooling for high traffic
- Query optimization for location history

### Frontend Optimization
- Code splitting for large components
- Lazy loading for map components
- Efficient state management
- Optimized bundle size

### Real-time Features
- WebSocket implementation for live updates
- Efficient polling strategies
- Location update batching
- Push notification integration

## Monitoring and Logging

### Application Monitoring
- Error tracking and reporting
- Performance metrics collection
- User activity analytics
- System health monitoring

### Security Monitoring
- Failed authentication attempts
- Suspicious location updates
- Emergency alert patterns
- Data access auditing

## Testing Strategy

### Backend Testing
- Unit tests for API endpoints
- Integration tests for database operations
- Security testing for authentication
- Load testing for concurrent users

### Frontend Testing
- Component unit tests
- Integration tests for user flows
- End-to-end testing with Cypress
- Cross-browser compatibility testing

## Maintenance and Updates

### Regular Maintenance
- Database cleanup and optimization
- Security patch updates
- Performance monitoring and tuning
- User feedback integration

### Feature Updates
- New emergency features
- Enhanced location accuracy
- Additional device support
- Improved user interface

## Troubleshooting Guide

### Common Issues
1. **Location Not Updating**
   - Check device permissions
   - Verify GPS functionality
   - Confirm internet connectivity
   - Review consent status

2. **Authentication Problems**
   - Verify JWT token validity
   - Check password hash integrity
   - Confirm CORS configuration
   - Review session management

3. **Database Issues**
   - Check database connectivity
   - Verify table schema
   - Monitor query performance
   - Review data integrity

### Debug Mode
Enable debug mode for development:
```python
app.run(host='0.0.0.0', port=5000, debug=True)
```

### Logging Configuration
```python
import logging
logging.basicConfig(level=logging.INFO)
app.logger.setLevel(logging.INFO)
```

## Future Enhancements

### Planned Features
- Mobile app development (React Native)
- Advanced analytics and reporting
- Machine learning for threat detection
- Integration with emergency services
- Multi-language support
- Offline mode capabilities

### Scalability Improvements
- Microservices architecture
- Redis caching layer
- CDN for static assets
- Load balancing
- Database sharding

---

This technical documentation provides comprehensive information for developers working with the Live Location Tracker application. For user-facing documentation, refer to the User Guide.

