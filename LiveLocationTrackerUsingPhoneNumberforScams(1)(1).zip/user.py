from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    phone_number = db.Column(db.String(20))
    phone_verified = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    devices = db.relationship('Device', backref='user', lazy=True, cascade='all, delete-orphan')
    emergency_contacts = db.relationship('EmergencyContact', backref='user', lazy=True, cascade='all, delete-orphan')
    geofences = db.relationship('Geofence', backref='user', lazy=True, cascade='all, delete-orphan')
    notifications = db.relationship('Notification', backref='user', lazy=True, cascade='all, delete-orphan')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f'<User {self.email}>'

    def to_dict(self):
        return {
            'id': self.id,
            'email': self.email,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'phone_number': self.phone_number,
            'phone_verified': self.phone_verified,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'is_active': self.is_active
        }

class Device(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    device_name = db.Column(db.String(100), nullable=False)
    device_identifier = db.Column(db.String(255), unique=True, nullable=False)
    device_type = db.Column(db.String(50))  # 'android', 'ios', 'web'
    consent_status = db.Column(db.String(20), default='pending')  # 'pending', 'active', 'paused', 'revoked'
    consent_timestamp = db.Column(db.DateTime)
    last_location_lat = db.Column(db.Numeric(10, 8))
    last_location_lng = db.Column(db.Numeric(11, 8))
    last_location_timestamp = db.Column(db.DateTime)
    last_location_accuracy = db.Column(db.Numeric(8, 2))
    battery_level = db.Column(db.Integer)
    is_online = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    location_history = db.relationship('LocationHistory', backref='device', lazy=True, cascade='all, delete-orphan')
    geofences = db.relationship('Geofence', backref='device', lazy=True, cascade='all, delete-orphan')
    emergency_alerts = db.relationship('EmergencyAlert', backref='device', lazy=True, cascade='all, delete-orphan')
    notifications = db.relationship('Notification', backref='device', lazy=True, cascade='all, delete-orphan')

    def __repr__(self):
        return f'<Device {self.device_name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'device_name': self.device_name,
            'device_type': self.device_type,
            'consent_status': self.consent_status,
            'last_location': {
                'latitude': float(self.last_location_lat) if self.last_location_lat else None,
                'longitude': float(self.last_location_lng) if self.last_location_lng else None,
                'timestamp': self.last_location_timestamp.isoformat() if self.last_location_timestamp else None,
                'accuracy': float(self.last_location_accuracy) if self.last_location_accuracy else None
            },
            'battery_level': self.battery_level,
            'is_online': self.is_online,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class LocationHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    device_id = db.Column(db.Integer, db.ForeignKey('device.id'), nullable=False)
    latitude = db.Column(db.Numeric(10, 8), nullable=False)
    longitude = db.Column(db.Numeric(11, 8), nullable=False)
    accuracy = db.Column(db.Numeric(8, 2))
    altitude = db.Column(db.Numeric(8, 2))
    speed = db.Column(db.Numeric(8, 2))
    heading = db.Column(db.Numeric(5, 2))
    location_source = db.Column(db.String(20))  # 'gps', 'wifi', 'cellular'
    timestamp = db.Column(db.DateTime, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<LocationHistory {self.device_id} at {self.timestamp}>'

    def to_dict(self):
        return {
            'id': self.id,
            'latitude': float(self.latitude),
            'longitude': float(self.longitude),
            'accuracy': float(self.accuracy) if self.accuracy else None,
            'altitude': float(self.altitude) if self.altitude else None,
            'speed': float(self.speed) if self.speed else None,
            'heading': float(self.heading) if self.heading else None,
            'location_source': self.location_source,
            'timestamp': self.timestamp.isoformat()
        }

class EmergencyContact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    contact_name = db.Column(db.String(100), nullable=False)
    phone_number = db.Column(db.String(20), nullable=False)
    relationship = db.Column(db.String(50))
    is_primary = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f'<EmergencyContact {self.contact_name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'contact_name': self.contact_name,
            'phone_number': self.phone_number,
            'relationship': self.relationship,
            'is_primary': self.is_primary
        }

class Geofence(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    device_id = db.Column(db.Integer, db.ForeignKey('device.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    center_lat = db.Column(db.Numeric(10, 8), nullable=False)
    center_lng = db.Column(db.Numeric(11, 8), nullable=False)
    radius = db.Column(db.Numeric(8, 2), nullable=False)
    fence_type = db.Column(db.String(20), default='circular')
    alert_on_enter = db.Column(db.Boolean, default=True)
    alert_on_exit = db.Column(db.Boolean, default=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    geofence_events = db.relationship('GeofenceEvent', backref='geofence', lazy=True, cascade='all, delete-orphan')

    def __repr__(self):
        return f'<Geofence {self.name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'center_lat': float(self.center_lat),
            'center_lng': float(self.center_lng),
            'radius': float(self.radius),
            'alert_on_enter': self.alert_on_enter,
            'alert_on_exit': self.alert_on_exit,
            'is_active': self.is_active
        }

class GeofenceEvent(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    geofence_id = db.Column(db.Integer, db.ForeignKey('geofence.id'), nullable=False)
    device_id = db.Column(db.Integer, db.ForeignKey('device.id'), nullable=False)
    event_type = db.Column(db.String(10), nullable=False)  # 'enter', 'exit'
    latitude = db.Column(db.Numeric(10, 8), nullable=False)
    longitude = db.Column(db.Numeric(11, 8), nullable=False)
    timestamp = db.Column(db.DateTime, nullable=False)
    alert_sent = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<GeofenceEvent {self.event_type} at {self.timestamp}>'

    def to_dict(self):
        return {
            'id': self.id,
            'event_type': self.event_type,
            'latitude': float(self.latitude),
            'longitude': float(self.longitude),
            'timestamp': self.timestamp.isoformat(),
            'alert_sent': self.alert_sent
        }

class EmergencyAlert(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    device_id = db.Column(db.Integer, db.ForeignKey('device.id'), nullable=False)
    alert_type = db.Column(db.String(50), nullable=False)
    latitude = db.Column(db.Numeric(10, 8))
    longitude = db.Column(db.Numeric(11, 8))
    message = db.Column(db.Text)
    is_resolved = db.Column(db.Boolean, default=False)
    resolved_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<EmergencyAlert {self.alert_type} at {self.created_at}>'

    def to_dict(self):
        return {
            'id': self.id,
            'device_id': self.device_id,
            'alert_type': self.alert_type,
            'latitude': float(self.latitude) if self.latitude else None,
            'longitude': float(self.longitude) if self.longitude else None,
            'message': self.message,
            'is_resolved': self.is_resolved,
            'resolved_at': self.resolved_at.isoformat() if self.resolved_at else None,
            'created_at': self.created_at.isoformat()
        }

class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    device_id = db.Column(db.Integer, db.ForeignKey('device.id'))
    notification_type = db.Column(db.String(50), nullable=False)
    recipient = db.Column(db.String(255), nullable=False)
    subject = db.Column(db.String(255))
    message = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='pending')
    sent_at = db.Column(db.DateTime)
    delivered_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<Notification {self.notification_type} to {self.recipient}>'

    def to_dict(self):
        return {
            'id': self.id,
            'notification_type': self.notification_type,
            'recipient': self.recipient,
            'subject': self.subject,
            'message': self.message,
            'status': self.status,
            'sent_at': self.sent_at.isoformat() if self.sent_at else None,
            'created_at': self.created_at.isoformat()
        }

