# Database Schema Design for Live Location Tracker Application

## Overview
This document outlines the database schema for the Live Location Tracker Application. The schema is designed to support user management, device tracking, location history, emergency contacts, and geofencing features while maintaining data integrity and security.

## Database Tables

### 1. Users Table
Stores user account information and authentication details.

```sql
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    phone_number VARCHAR(20),
    phone_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);
```

### 2. Devices Table
Stores information about enrolled devices for tracking.

```sql
CREATE TABLE devices (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    device_name VARCHAR(100) NOT NULL,
    device_identifier VARCHAR(255) UNIQUE NOT NULL, -- Unique device ID/token
    device_type VARCHAR(50), -- 'android', 'ios', 'web'
    consent_status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'active', 'paused', 'revoked'
    consent_timestamp TIMESTAMP,
    last_location_lat DECIMAL(10, 8),
    last_location_lng DECIMAL(11, 8),
    last_location_timestamp TIMESTAMP,
    last_location_accuracy DECIMAL(8, 2), -- in meters
    battery_level INTEGER, -- 0-100
    is_online BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 3. Location History Table
Stores historical location data for all tracked devices.

```sql
CREATE TABLE location_history (
    id SERIAL PRIMARY KEY,
    device_id INTEGER REFERENCES devices(id) ON DELETE CASCADE,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    accuracy DECIMAL(8, 2), -- in meters
    altitude DECIMAL(8, 2), -- in meters
    speed DECIMAL(8, 2), -- in m/s
    heading DECIMAL(5, 2), -- in degrees
    location_source VARCHAR(20), -- 'gps', 'wifi', 'cellular'
    timestamp TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Index for efficient querying by device and time
CREATE INDEX idx_location_history_device_timestamp ON location_history(device_id, timestamp DESC);
```

### 4. Emergency Contacts Table
Stores emergency contact information for users.

```sql
CREATE TABLE emergency_contacts (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    contact_name VARCHAR(100) NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    relationship VARCHAR(50), -- 'parent', 'spouse', 'friend', 'guardian', etc.
    is_primary BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 5. Geofences Table
Stores geofence definitions for location-based alerts.

```sql
CREATE TABLE geofences (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    device_id INTEGER REFERENCES devices(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    center_lat DECIMAL(10, 8) NOT NULL,
    center_lng DECIMAL(11, 8) NOT NULL,
    radius DECIMAL(8, 2) NOT NULL, -- in meters
    fence_type VARCHAR(20) DEFAULT 'circular', -- 'circular', 'polygon' (future)
    alert_on_enter BOOLEAN DEFAULT TRUE,
    alert_on_exit BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 6. Geofence Events Table
Logs geofence entry/exit events for tracking and alerting.

```sql
CREATE TABLE geofence_events (
    id SERIAL PRIMARY KEY,
    geofence_id INTEGER REFERENCES geofences(id) ON DELETE CASCADE,
    device_id INTEGER REFERENCES devices(id) ON DELETE CASCADE,
    event_type VARCHAR(10) NOT NULL, -- 'enter', 'exit'
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    timestamp TIMESTAMP NOT NULL,
    alert_sent BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Index for efficient querying
CREATE INDEX idx_geofence_events_device_timestamp ON geofence_events(device_id, timestamp DESC);
```

### 7. Emergency Alerts Table
Logs emergency alerts (panic button activations, geofence breaches, etc.).

```sql
CREATE TABLE emergency_alerts (
    id SERIAL PRIMARY KEY,
    device_id INTEGER REFERENCES devices(id) ON DELETE CASCADE,
    alert_type VARCHAR(50) NOT NULL, -- 'panic_button', 'geofence_breach', 'low_battery', etc.
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    message TEXT,
    is_resolved BOOLEAN DEFAULT FALSE,
    resolved_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 8. Notifications Table
Stores notification history for SMS and in-app alerts.

```sql
CREATE TABLE notifications (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    device_id INTEGER REFERENCES devices(id) ON DELETE CASCADE,
    notification_type VARCHAR(50) NOT NULL, -- 'sms', 'email', 'push', 'in_app'
    recipient VARCHAR(255) NOT NULL, -- phone number, email, or user ID
    subject VARCHAR(255),
    message TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'sent', 'delivered', 'failed'
    sent_at TIMESTAMP,
    delivered_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 9. API Keys Table
Stores encrypted API keys for third-party services (phone verification, SMS, etc.).

```sql
CREATE TABLE api_keys (
    id SERIAL PRIMARY KEY,
    service_name VARCHAR(100) NOT NULL, -- 'numverify', 'twilio', 'google_maps'
    key_name VARCHAR(100) NOT NULL,
    encrypted_key TEXT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Relationships Summary

1. **Users** can have multiple **Devices** (1:N)
2. **Users** can have multiple **Emergency Contacts** (1:N)
3. **Devices** can have multiple **Location History** entries (1:N)
4. **Users** can create multiple **Geofences** for their **Devices** (1:N)
5. **Geofences** can generate multiple **Geofence Events** (1:N)
6. **Devices** can trigger multiple **Emergency Alerts** (1:N)
7. **Users** and **Devices** can receive multiple **Notifications** (1:N)

## Data Retention and Privacy Considerations

1. **Location History Retention:** Location data should be automatically purged after a configurable period (e.g., 30-90 days) to comply with data minimization principles.
2. **Soft Deletes:** Consider implementing soft deletes for critical data to maintain referential integrity while allowing users to "delete" their data.
3. **Encryption:** Sensitive fields (location coordinates, phone numbers) should be encrypted at the application level before storage.
4. **Audit Trail:** Consider adding audit tables to track data access and modifications for compliance purposes.

## Performance Optimizations

1. **Indexing:** Proper indexing on frequently queried columns (device_id, timestamp, user_id).
2. **Partitioning:** Consider table partitioning for location_history based on timestamp for better performance with large datasets.
3. **Caching:** Implement caching strategies for frequently accessed data (current device locations, user preferences).

This schema provides a solid foundation for the Live Location Tracker Application while maintaining flexibility for future enhancements and ensuring compliance with privacy regulations.

