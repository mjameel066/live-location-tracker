import axios from 'axios'

// Create axios instance with base configuration
export const api = axios.create({
  baseURL: 'http://localhost:5000/api', // Point to Flask backend
  headers: {
    'Content-Type': 'application/json',
  },
})

// Add request interceptor to include auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Add response interceptor to handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      localStorage.removeItem('token')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

// API helper functions
export const authAPI = {
  login: (email, password) => api.post('/auth/login', { email, password }),
  register: (userData) => api.post('/auth/register', userData),
  logout: () => api.post('/auth/logout'),
}

export const userAPI = {
  getProfile: () => api.get('/users/profile'),
  updateProfile: (data) => api.put('/users/profile', data),
  changePassword: (data) => api.post('/users/change-password', data),
}

export const deviceAPI = {
  getDevices: () => api.get('/devices/'),
  registerDevice: (data) => api.post('/devices/', data),
  updateDevice: (deviceId, data) => api.put(`/devices/${deviceId}`, data),
  deleteDevice: (deviceId) => api.delete(`/devices/${deviceId}`),
  updateConsent: (deviceId, status) => api.put(`/devices/${deviceId}/consent`, { consent_status: status }),
}

export const locationAPI = {
  getCurrentLocation: (deviceId) => api.get(`/locations/${deviceId}/current`),
  getLocationHistory: (deviceId, params = {}) => api.get(`/locations/${deviceId}/history`, { params }),
  submitLocation: (data) => api.post('/locations/', data),
}

export const emergencyAPI = {
  getAlerts: (params = {}) => api.get('/emergency/alerts', { params }),
  resolveAlert: (alertId) => api.put(`/emergency/alerts/${alertId}/resolve`),
  triggerPanic: (data) => api.post('/emergency/panic', data),
  getContacts: () => api.get('/emergency/contacts'),
  addContact: (data) => api.post('/emergency/contacts', data),
  updateContact: (contactId, data) => api.put(`/emergency/contacts/${contactId}`, data),
  deleteContact: (contactId) => api.delete(`/emergency/contacts/${contactId}`),
}

export const geofenceAPI = {
  getGeofences: () => api.get('/geofences/'),
  createGeofence: (data) => api.post('/geofences/', data),
  updateGeofence: (geofenceId, data) => api.put(`/geofences/${geofenceId}`, data),
  deleteGeofence: (geofenceId) => api.delete(`/geofences/${geofenceId}`),
  getGeofenceEvents: (geofenceId, params = {}) => api.get(`/geofences/${geofenceId}/events`, { params }),
  getDeviceGeofences: (deviceId) => api.get(`/geofences/device/${deviceId}`),
}

export const phoneAPI = {
  verifyPhone: (phoneNumber) => api.post('/phone/verify', { phone_number: phoneNumber }),
  lookupPhone: (phoneNumber) => api.post('/phone/lookup', { phone_number: phoneNumber }),
  validateUserPhone: (phoneNumber) => api.post('/phone/validate-user', { phone_number: phoneNumber }),
}

